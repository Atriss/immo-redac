# Générateur d'annonces immo — Claude

## Structure du projet

```
generateur-annonces/
├── netlify/
│   └── functions/
│       └── claude-proxy.js   ← proxy sécurisé vers l'API Anthropic
├── public/
│   └── index.html            ← interface utilisateur
├── netlify.toml              ← configuration Netlify
└── README.md
```

## Déploiement sur Netlify

### 1. Créer un dépôt GitHub
- Va sur github.com → New repository → "generateur-annonces-immo"
- Uploade tous les fichiers du projet

### 2. Connecter à Netlify
- Va sur app.netlify.com → "Add new site" → "Import an existing project"
- Sélectionne ton dépôt GitHub
- Paramètres de build :
  - Build command : (laisser vide)
  - Publish directory : `public`
  - Functions directory : `netlify/functions`

### 3. Ajouter la clé API Anthropic
Dans Netlify → Site settings → Environment variables → Add variable :
- Key : `ANTHROPIC_API_KEY`
- Value : ta clé API (commence par `sk-ant-...`)

Obtenir une clé : https://console.anthropic.com/

### 4. Déployer
Netlify déploie automatiquement à chaque push GitHub.
Ton site sera disponible sur : https://xxx.netlify.app

## Fonctionnement

```
Navigateur → /api/claude → Netlify Function → API Anthropic → Réponse
```

La clé API n'est jamais exposée côté client.

## Évolutions possibles
- Système de compte (Supabase) pour gérer des abonnements
- Historique des annonces générées par utilisateur
- Export PDF de l'annonce
- Limite de génération gratuite + plan premium (Stripe)
